package com.wipro.article2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Article2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
