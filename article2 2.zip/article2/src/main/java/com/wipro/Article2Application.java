package com.wipro;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Article2Application {

	public static void main(String[] args) {
		SpringApplication.run(Article2Application.class, args);
	}

}
